# Glomaris Castillo | Plataforma de Leads

Plataforma conectada a Supabase para captar prospectos de seguros de vida.

## Incluye

- Sitio público premium
- Evaluación Familiar Gratuita
- Calculadora educativa
- WhatsApp directo
- Panel privado en `/admin`
- Leads guardados en Supabase
- CRM con estados, notas y exportación CSV

## Publicar con GitHub + Netlify

1. Crea una cuenta en GitHub.
2. Crea un repositorio nuevo.
3. Sube todos los archivos de esta carpeta.
4. En Netlify, entra a **Add new site**.
5. Selecciona **Import from Git**.
6. Conecta GitHub.
7. Selecciona el repositorio.
8. En configuración de build:
   - Build command: dejar vacío
   - Publish directory: `.`
9. Publica.

## Panel privado

Una vez publicado:

`tu-dominio.com/admin`

Contraseña inicial:

`Glomaris2026`

## Supabase

La aplicación ya está conectada al proyecto Supabase suministrado.

Si no guarda leads, revisa en Supabase:

- Table Editor → leads
- RLS desactivado, o políticas activas para insert/select/update/delete.

## Próximo paso recomendado

Conectar login real con Supabase Auth para proteger mejor el panel privado.
