const SUPABASE_URL = "https://lfzftarfwwxetthowrwj.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxmemZ0YXJmd3d4ZXR0aG93cndqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI5NDYyNDcsImV4cCI6MjA5ODUyMjI0N30.cCA5CMwt25zY-oL0CtIEnaB1P6uDXQpbq-fvtiSkUmU";

const steps=[...document.querySelectorAll(".step")];
const progress=document.getElementById("progress");
let current=0, answers={}, scores=[];

function show(i){
  steps.forEach((s,idx)=>s.classList.toggle("active",idx===i));
  progress.style.width=Math.min(((i+1)/(steps.length-1))*100,100)+"%";
}

function resultText(total){
  if(total>=12) return "Con base en tus respuestas, vale la pena revisar alternativas de protección para tu familia lo antes posible. Me encantará orientarte y responder tus preguntas.";
  if(total>=8) return "Tus respuestas muestran que hay puntos importantes que conviene revisar para encontrar una opción adecuada para tu familia y presupuesto.";
  return "Este puede ser un buen momento para recibir orientación y entender tus opciones con calma, sin compromiso.";
}

async function saveLeadToSupabase(lead){
  const response = await fetch(`${SUPABASE_URL}/rest/v1/leads`, {
    method: "POST",
    headers: {
      "apikey": SUPABASE_ANON_KEY,
      "Authorization": `Bearer ${SUPABASE_ANON_KEY}`,
      "Content-Type": "application/json",
      "Prefer": "return=representation"
    },
    body: JSON.stringify(lead)
  });

  if(!response.ok){
    const errorText = await response.text();
    console.error("Error guardando lead:", errorText);
    throw new Error(errorText);
  }

  return await response.json();
}

document.querySelectorAll(".step button[data-score]").forEach(btn=>btn.onclick=()=>{
  const step=btn.closest(".step");
  answers[step.dataset.key]=btn.innerText.trim();
  scores.push(Number(btn.dataset.score||0));
  current++;
  show(current);
});

document.getElementById("survey").onsubmit=async e=>{
  e.preventDefault();

  const fd=new FormData(e.target);
  const total=scores.reduce((a,b)=>a+b,0);
  const texto=resultText(total);

  const lead={
    nombre:fd.get("nombre")||"",
    telefono:fd.get("telefono")||"",
    email:fd.get("email")||"",
    ciudad:fd.get("ciudad")||"",
    horario:fd.get("horario")||"",
    resultado:texto,
    edad:answers.edad||"",
    dependientes:answers.dependientes||"",
    seguro:answers.seguro||"",
    objetivo:answers.objetivo||"",
    presupuesto:answers.presupuesto||"",
    estado:"Nuevo",
    notas:""
  };

  const submitBtn = e.target.querySelector('button[type="submit"]');
  submitBtn.disabled = true;
  submitBtn.innerText = "Guardando...";

  try{
    await saveLeadToSupabase(lead);
    document.getElementById("resultText").innerText=texto;
  }catch(error){
    document.getElementById("resultText").innerText="Gracias por completar la evaluación. Si el sistema tarda en guardar tus datos, también puedes enviarme tus respuestas directamente por WhatsApp.";
  }

  const msg=`Hola Glomaris, acabo de completar la Evaluación Familiar Gratuita.

Mis datos:
Nombre: ${lead.nombre}
Teléfono: ${lead.telefono}
Email: ${lead.email}
Ciudad/Estado: ${lead.ciudad}
Mejor horario: ${lead.horario}

Mis respuestas:
Edad: ${lead.edad}
Dependientes: ${lead.dependientes}
Seguro actual: ${lead.seguro}
Objetivo: ${lead.objetivo}
Presupuesto: ${lead.presupuesto}

Me gustaría recibir orientación sobre mis opciones de seguro de vida.`;

  document.getElementById("waLink").href="https://wa.me/13466241906?text="+encodeURIComponent(msg);
  current=steps.length-1;
  show(current);
  submitBtn.disabled = false;
  submitBtn.innerText = "Ver mi resultado";
};

document.getElementById("restart").onclick=()=>{
  answers={};
  scores=[];
  current=0;
  document.getElementById("survey").reset();
  show(0);
};

document.getElementById("calcBtn").onclick=()=>{
  const income=Number(document.getElementById("income").value||0);
  const years=Number(document.getElementById("years").value||0);
  const debts=Number(document.getElementById("debts").value||0);
  const out=document.getElementById("calcResult");

  if(!income||!years){
    out.innerText="Completa el ingreso mensual y los años de protección.";
    return;
  }

  out.innerText=`Estimado educativo: $${(income*12*years+debts).toLocaleString("en-US")} de protección.`;
};