const SUPABASE_URL = "https://lfzftarfwwxetthowrwj.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxmemZ0YXJmd3d4ZXR0aG93cndqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI5NDYyNDcsImV4cCI6MjA5ODUyMjI0N30.cCA5CMwt25zY-oL0CtIEnaB1P6uDXQpbq-fvtiSkUmU";
const PASS="Glomaris2026";

const login=document.getElementById("login");
const dash=document.getElementById("dashboard");

if(localStorage.getItem("gc_logged")==="yes"){
  login.classList.add("hidden");
  dash.classList.remove("hidden");
  render();
}

document.getElementById("enter").onclick=()=>{
  if(document.getElementById("password").value===PASS){
    localStorage.setItem("gc_logged","yes");
    login.classList.add("hidden");
    dash.classList.remove("hidden");
    render();
  } else {
    alert("Contraseña incorrecta");
  }
};

document.getElementById("logout").onclick=()=>{
  localStorage.removeItem("gc_logged");
  location.reload();
};

async function supabaseRequest(path, options={}){
  const response = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    ...options,
    headers: {
      "apikey": SUPABASE_ANON_KEY,
      "Authorization": `Bearer ${SUPABASE_ANON_KEY}`,
      "Content-Type": "application/json",
      "Prefer": "return=representation",
      ...(options.headers || {})
    }
  });

  if(!response.ok){
    const text = await response.text();
    console.error(text);
    throw new Error(text);
  }

  if(response.status === 204) return null;
  return await response.json();
}

async function getLeads(){
  return await supabaseRequest("leads?select=*&order=created_at.desc");
}

async function insertLead(lead){
  return await supabaseRequest("leads", {
    method: "POST",
    body: JSON.stringify(lead)
  });
}

async function updateLead(id, data){
  return await supabaseRequest(`leads?id=eq.${id}`, {
    method: "PATCH",
    body: JSON.stringify(data)
  });
}

async function deleteLead(id){
  return await supabaseRequest(`leads?id=eq.${id}`, {
    method: "DELETE"
  });
}

document.getElementById("leadForm").onsubmit=async e=>{
  e.preventDefault();

  const fd=new FormData(e.target);
  await insertLead({
    nombre:fd.get("nombre"),
    telefono:fd.get("telefono"),
    email:fd.get("email"),
    ciudad:fd.get("ciudad"),
    estado:fd.get("estado"),
    notas:""
  });

  e.target.reset();
  render();
};

function cleanPhone(phone){
  const digits = String(phone||"").replace(/\D/g,"");
  if(digits.startsWith("1")) return digits;
  return "1" + digits;
}

async function render(){
  const rows=document.getElementById("rows");
  rows.innerHTML=`<tr><td colspan="7">Cargando prospectos...</td></tr>`;

  try{
    const leads=await getLeads();

    document.getElementById("total").innerText=leads.length;
    document.getElementById("newCount").innerText=leads.filter(l=>l.estado==="Nuevo").length;
    document.getElementById("apptCount").innerText=leads.filter(l=>l.estado==="Cita").length;
    document.getElementById("salesCount").innerText=leads.filter(l=>l.estado==="Venta").length;

    rows.innerHTML="";

    if(!leads.length){
      rows.innerHTML=`<tr><td colspan="7">Todavía no hay prospectos.</td></tr>`;
      return;
    }

    leads.forEach(l=>{
      const tr=document.createElement("tr");
      const fecha = l.created_at ? new Date(l.created_at).toLocaleString() : "";
      tr.innerHTML=`
        <td>${fecha}</td>
        <td><strong>${l.nombre||""}</strong><br><small>${l.email||""}</small></td>
        <td>${l.telefono||""}</td>
        <td>${l.ciudad||""}</td>
        <td>
          <select data-id="${l.id}" class="estado">
            ${["Nuevo","Contactado","Cita","Seguimiento","Venta","No interesado"].map(s=>`<option ${l.estado===s?"selected":""}>${s}</option>`).join("")}
          </select>
        </td>
        <td><textarea data-id="${l.id}" class="notas">${l.notas||""}</textarea></td>
        <td>
          <a target="_blank" href="https://wa.me/${cleanPhone(l.telefono)}">WhatsApp</a><br>
          <button class="delete" data-id="${l.id}">Borrar</button>
        </td>`;
      rows.appendChild(tr);
    });

    document.querySelectorAll(".estado").forEach(x=>x.onchange=async()=>{
      await updateLead(x.dataset.id,{estado:x.value});
      render();
    });

    document.querySelectorAll(".notas").forEach(x=>x.onchange=async()=>{
      await updateLead(x.dataset.id,{notas:x.value});
      render();
    });

    document.querySelectorAll(".delete").forEach(x=>x.onclick=async()=>{
      if(confirm("¿Borrar prospecto?")){
        await deleteLead(x.dataset.id);
        render();
      }
    });

  }catch(error){
    rows.innerHTML=`<tr><td colspan="7">No se pudieron cargar los prospectos. Revisa las políticas de Supabase.</td></tr>`;
  }
}

document.getElementById("export").onclick=async()=>{
  const leads=await getLeads();
  if(!leads.length){
    alert("No hay prospectos");
    return;
  }

  const headers=["id","created_at","nombre","telefono","email","ciudad","horario","edad","dependientes","seguro","objetivo","presupuesto","resultado","estado","notas"];
  const csv=headers.join(",")+"\n"+leads.map(l=>headers.map(h=>`"${String(l[h]||"").replaceAll('"','""')}"`).join(",")).join("\n");
  const a=document.createElement("a");
  a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));
  a.download="prospectos_glomaris.csv";
  a.click();
};