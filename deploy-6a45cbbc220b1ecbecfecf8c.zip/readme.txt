VERSIÓN 4.0 - CONECTADA A SUPABASE

Esta versión:
- Guarda los leads automáticamente en Supabase.
- El panel /admin lee los leads desde Supabase.
- Puedes cambiar estado, agregar notas, borrar y exportar CSV.

Publicación:
1. Sube este ZIP completo a Netlify.
2. Sitio público: tu enlace normal.
3. Panel privado: tu-enlace-netlify/admin
4. Contraseña inicial del panel: Glomaris2026

IMPORTANTE SOBRE SUPABASE:
Si al probar no guarda o no carga leads, revisa que RLS no esté bloqueando la tabla.

Opción simple para empezar:
Supabase → Table Editor → leads → RLS debe estar desactivado.

O si tienes RLS activado, usa estas políticas en SQL Editor:

alter table leads enable row level security;

create policy "Permitir insertar leads"
on leads for insert
to anon
with check (true);

create policy "Permitir leer leads"
on leads for select
to anon
using (true);

create policy "Permitir actualizar leads"
on leads for update
to anon
using (true)
with check (true);

create policy "Permitir borrar leads"
on leads for delete
to anon
using (true);

Nota:
Esta es una versión funcional para empezar. Para máxima seguridad, el siguiente paso sería un login real con Supabase Auth.
